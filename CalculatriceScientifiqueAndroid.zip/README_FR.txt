CALCULATRICE SCIENTIFIQUE ANDROID — PROJET À COMPILER

Ce dossier contient le projet source Android Studio. Ce n'est pas encore un fichier APK installable.

Pour produire le fichier APK :
1. Installer Android Studio sur un ordinateur.
2. Décompresser ce ZIP.
3. Dans Android Studio, choisir Open puis sélectionner le dossier CalculatriceScientifiqueAndroid.
4. Attendre la synchronisation Gradle et l'installation des composants Android demandés.
5. Dans le menu Build, choisir Build Bundle(s) / APK(s) > Build APK(s).
6. Le fichier généré se trouvera normalement dans app/build/outputs/apk/debug/app-debug.apk.

L'application fonctionne hors ligne et n'exige aucune permission spéciale.
Configuration : Android minimum 6.0 (API 23).
